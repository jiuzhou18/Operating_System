#include "types.h"
#include "syscall.h"
#include "user.h"

int main(void)
{
	
	int pid = fork();
	wait();
	int i, j, testuse;
	for(i = 0; i < 5; i++){
		testuse = 0;
		int time = 1000000*getpid();
		for(j = 0; j < time; j++){
			testuse += 1;
		}
		sleep(0);
	}
	if(pid != 0){
		char test[10];
		printf(1,"Please just press enter for process %d:", getpid());
	 	gets(test, sizeof(test));
	}
	print_trapscount();
	print_trapstype();
	print_ticks();

	exit();

}