#include "types.h"
#include "syscall.h"
#include "user.h"
#include "stat.h"
#include "fs.h"


#define DIRSIZ 14

int strncmp(const char*, const char*, uint);

int main(void)
{
	
	int aiminum = -1;
	char* path = "/";
	char aimname[DIRSIZ];
	printf(1,"Please enter the file name that you want to erase from path \"%s\" (\"quit\" for exiting the loop)\n", path);
	gets(aimname, sizeof(aimname));
	int i = 0;
	while(aimname[0]!='q'|| aimname[1]!='u'|| aimname[2]!='i' || aimname[3]!='t'){
		//Clean the '\n' notation.
		for(i=0; i< DIRSIZ; i++){
			if(aimname[i] == '\n' || aimname[i] == '\r')
				aimname[i] = '\0';
		}
		//Erase the infomation of dirent of aimname.
		if((aiminum = erase_directory(path, aimname)) >= 0){ 
			printf(1,"Main: Inum %d with name \"%s\"has been erased in directroy path \"%s\".\n\n", aiminum, aimname, path); 
		}else{
			printf(1,"Main: Has not found the name \"%s\" in directroy path \"%s\".\n\n", aimname, path); 
		}	
		printf(1,"Please enter the file name that you want to erase from path \"%s\" (\"quit\" for exiting the loop)\n", path);
		gets(aimname, sizeof(aimname));
	}
	int size = 0;
	size = directory_walker(path, 0 , 0, 0 , 0 , 0 , 0);
	printf(1,"Directory Walker -- There are %d files and directroies in path of \"%s\":\n", size, path);
	unsigned int inums[size];
	unsigned int devs[size];
	short types[size];
	char allname[size][DIRSIZ];
	directory_walker(path, 1, size, inums, devs, types, *allname);

	for(i=0; i<size; i++){
		printf(1,"Inum:%d, name:%s, type:%d\n", inums[i], allname[i], types[i]);		
	}

	exit();

}
