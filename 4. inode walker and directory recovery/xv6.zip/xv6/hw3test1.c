#include "types.h"
#include "syscall.h"
#include "user.h"
#include "stat.h"

int main(void)
{
	int* p;
	p = (int*)0x1000;
	printf(1, "Read from the address 0x1000: %d\n", *p);
	printf(1, "Read from the address 0x0: %d\n", *((int*)0x0));
	exit();
}