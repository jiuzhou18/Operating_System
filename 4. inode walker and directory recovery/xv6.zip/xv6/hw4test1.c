#include "types.h"
#include "syscall.h"
#include "user.h"
#include "stat.h"
#include "fs.h"

#define DIRSIZ 14

int main(void)
{
	int size = 0;
	char* path = "/";
	size = directory_walker(path, 0 , 0, 0 , 0 , 0 , 0);
	printf(1,"Directory Walker -- There are %d files and directroies in path of \"%s\":\n", size, path);
	unsigned int inums[size];
	unsigned int devs[size];
	short types[size];
	char allname[size][DIRSIZ];
	directory_walker(path, 1, size, inums, devs, types, *allname);
	int i;
	for(i=0; i<size; i++){
		// printf(1,"Inum:%d, name:%s, type:%d, dev:%d\n", inums[i], allname[i], types[i], devs[i]);	
		printf(1,"Inum:%d, name:%s, type:%d\n", inums[i], allname[i], types[i]);		
	}

	int size2 = 0;
	size2 = inode_walker(0, 0, 0, 0, 0);
	printf(1,"Inode Walker -- There are %d inodes:\n", size2);
	unsigned int inums2[size2];
	unsigned int devs2[size2];
	short types2[size2];
	inode_walker(1, size2, inums2, devs2, types2);
	for(i=0; i<size2; i++){
		// printf(1,"Inum:%d, dev:%d, type:%d\n", inums2[i], devs2[i], types2[i]);	
		printf(1,"Inum:%d, type:%d\n", inums2[i], types2[i]);
		// if(i%5 == 4) printf(1,"\n");	
	}

	char test[10];
	printf(1,"\nPlease just press enter to start comparation:");
	 gets(test, sizeof(test));

	unsigned int inumsarrange[size];
	for(i=0; i<size; i++){
		inumsarrange[i] = inums[i];
	}
	int j, change, temp;
	for(i=0; i<size; i++){
		change = i;
		for(j=i; j<size; j++){
			if(inumsarrange[change] > inumsarrange[j])
				change = j;
		}
		temp = inumsarrange[change];
		inumsarrange[change] = inumsarrange[i];
		inumsarrange[i] = temp;
	}
	i = 0; j = 0;
	// int match = 1;
	while(i < size || j < size2){
		if(inumsarrange[i] == inums2[j]){
			printf(1,"Inum %d\t from directroyWalker matches Inum %d\t from inodeWalker.\n", inumsarrange[i], inums2[j]);
			i++;
			j++;
		}else if(inumsarrange[i] > inums2[j]){
			printf(1,"Inum %d from inodeWalker unmatched.\n", inums2[j]);
			// match = -1;
			j++;
		}else{
			printf(1,"Inum %d from directroyWalker unmatched.\n", inumsarrange[i]);
			// match = -1;
			i++;
		}
	}

	exit();

}

