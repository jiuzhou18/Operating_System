#include "types.h"
#include "syscall.h"
#include "user.h"
#include "stat.h"


int main(void)
{
	char* addr = (char*)0x0;
	int state =  mkdir(addr);
	if(state < 0){
		printf(1, "mkdir failed as we expected.\n");	
	}else{
		printf(1, "This test failed.\n");
	}
	
	exit();
}

