#include "types.h"
#include "syscall.h"
#include "user.h"
#include "stat.h"
#include "fs.h"

#define DIRSIZ 14

int main(void)
{
	
	char* path = "/";
	int size = 0;
	size = directory_walker(path, 0 , 0, 0 , 0 , 0 , 0);
	printf(1,"Directory Walker -- There are %d files and directroies in path of \"%s\":\n", size, path);
	unsigned int inums[size];
	unsigned int devs[size];
	short types[size];
	char allname[size][DIRSIZ];
	directory_walker(path, 1, size, inums, devs, types, *allname);
	int i;
	

	int size2 = 0;
	size2 = inode_walker(0, 0, 0, 0, 0);
	printf(1,"\nInode Walker -- There are %d inodes.\n", size2);
	unsigned int inums2[size2];
	unsigned int devs2[size2];
	short types2[size2];
	inode_walker(1, size2, inums2, devs2, types2);

	
	printf(1,"\nStart comparation...\n");
	
	unsigned int inumsarrange[size];
	for(i=0; i<size; i++){
		inumsarrange[i] = inums[i];
	}
	int j, change, temp;
	for(i=0; i<size; i++){
		change = i;
		for(j=i; j<size; j++){
			if(inumsarrange[change] > inumsarrange[j])
				change = j;
		}
		temp = inumsarrange[change];
		inumsarrange[change] = inumsarrange[i];
		inumsarrange[i] = temp;
	}
	i = 0; j = 0;

	int maxsize = (size>size2)? size: size2 ;

	//Find the unmatched inode inum in directory.
	int index = 0;
	int unmatchInum[maxsize];
	while(i < size || j < size2){
		if(inumsarrange[i] == inums2[j]){
			// printf(1,"Inum %d\t from directoryWalker matches Inum %d\t from inodeWalker.\n", inumsarrange[i], inums2[j]);
			i++;
			j++;
		}else if(inumsarrange[i] > inums2[j]){
			printf(1,"Inum %d from inodeWalker unmatched!\n", inums2[j]);
			unmatchInum[index] = inums2[j];
			index++;
			j++;
		}else{
			printf(1,"Inum %d from directoryWalker unmatched!\n", inumsarrange[i]);
			// unmatchInum[index] = inumsarrange[i];
			// index++;
			i++;
		}
	}

	if(index>0){
		char test[10];
		printf(1,"\nPlease just press enter to start recovery:");
		gets(test, sizeof(test));

		//Recover the inodes in directory under default path "/"
		path = "/";
		char newname[10] = "recover  ";
		for(i=0; i<index; i++){
			newname[7] = 48 + i/10;
			newname[8] = 48 + i%10;
			printf(1,"Try to recover inum %d to directory \"%s\" with name \"%s\"\n", unmatchInum[i], path, newname);
			recover_directory(path, newname, unmatchInum[i]);
		}

		//Check whether recovered.
		int newsize = directory_walker(path, 0, 0, 0, 0, 0, 0);
		printf(1,"The size become: %d\n", newsize);		
		unsigned int inums3[newsize];
		unsigned int devs3[newsize];
		short types3[newsize];
		char allname3[newsize][DIRSIZ];
		directory_walker(path, 1, newsize, inums3, devs3, types3, *allname3);
		for(i=0; i<newsize; i++){
			printf(1,"Inum:%d, name:%s, type:%d\n", inums3[i], allname3[i], types3[i]);		
		}
	}else{
		printf(1,"No inode unmatched!\n");
	}

	exit();

}
