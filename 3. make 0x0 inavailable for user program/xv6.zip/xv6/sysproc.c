#include "types.h"
#include "x86.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return proc->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = proc->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;
  
  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(proc->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;
  
  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//Sum the tick time for process up to now, by adding the tick time in this period. (In order to not contain the trap time)
int
sys_sum_ticks(void)
{
  int nticks;
  nticks = sys_uptime();
  //cprintf("now is time %d \n", nticks);
  proc->total_ticks = proc->total_ticks + nticks - proc->next_start_tick;
  return 0;
}

//Initial the start the time when trap finished and the process continues.
int
sys_init_start(void)
{
  proc->next_start_tick = sys_uptime();
  return 0;
}

//Print the total tick time of the process.
int
sys_print_ticks(void)
{
  cprintf("The process %d took %d ticks. \n",proc->pid, proc->total_ticks);
  //cprintf("Start time is %d \n",proc->start_ticks);
  return proc->total_ticks;
}

//Print the count number of traps from the process.
int
sys_print_trapscount(void)
{
  cprintf("The OS traps occurred %d times from this process %d. \n", proc->trap_count, proc->pid);
  return proc->trap_count;
}

//Print the types of Top 100 traps from the process.
int
sys_print_trapstype(void)
{
  int i;
  cprintf("The traps types are: \n");
  for(i=0; i<proc->trap_count && i<100; i++){
    cprintf("%d \t", proc->trap_type[i]);
    if(i % 10 == 9)
      cprintf("\n");
  }
  cprintf("\n");
  return i;
}
